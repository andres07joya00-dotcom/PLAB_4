var searchData=
[
  ['usuario_0',['Usuario',['../classUsuario.html',1,'']]]
];
