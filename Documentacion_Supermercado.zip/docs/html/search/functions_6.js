var searchData=
[
  ['usuario_0',['Usuario',['../classUsuario.html#a887174e4b59fa5c02d47150fdbd7904b',1,'Usuario']]]
];
