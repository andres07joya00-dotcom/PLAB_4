var searchData=
[
  ['nombres_0',['nombres',['../classproducto.html#a9ccee66445b10e1df9d47b81f14ca63c',1,'producto']]]
];
