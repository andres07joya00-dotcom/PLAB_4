var searchData=
[
  ['getcantidad_0',['getCantidad',['../classitemcarrito.html#a8393edb822049ca50a4a113dd9df98bf',1,'itemcarrito']]],
  ['getnombre_1',['getNombre',['../classUsuario.html#a69eab5b3314e826c58aaa034479d7ac0',1,'Usuario']]],
  ['getnombres_2',['getNombres',['../classproducto.html#adfbcadf358ae307b02edf95d8bb0cebd',1,'producto']]],
  ['getprecios_3',['getPrecios',['../classproducto.html#aad29719885bb2e71f88de4b445af6a97',1,'producto']]],
  ['getproducto_4',['getProducto',['../classitemcarrito.html#a3cd6ed54e0e11a7b2755eeeb3da87c58',1,'itemcarrito']]],
  ['gettotal_5',['getTotal',['../classitemcarrito.html#a6ebd1de482e840751b97abd731e598dd',1,'itemcarrito']]],
  ['guardarcompra_6',['guardarCompra',['../classUsuario.html#ae80eaca178e9fd92688c8f0b9f172b0e',1,'Usuario']]]
];
