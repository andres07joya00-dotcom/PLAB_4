var classUsuario =
[
    [ "Usuario", "classUsuario.html#a887174e4b59fa5c02d47150fdbd7904b", null ],
    [ "getNombre", "classUsuario.html#a69eab5b3314e826c58aaa034479d7ac0", null ],
    [ "guardarCompra", "classUsuario.html#ae80eaca178e9fd92688c8f0b9f172b0e", null ],
    [ "mostrarHistorial", "classUsuario.html#a18f893ef5457ae77f0801d3c7c462f49", null ]
];