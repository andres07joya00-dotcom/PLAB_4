var hierarchy =
[
    [ "producto", "classproducto.html", [
      [ "itemcarrito", "classitemcarrito.html", null ]
    ] ],
    [ "Usuario", "classUsuario.html", null ]
];