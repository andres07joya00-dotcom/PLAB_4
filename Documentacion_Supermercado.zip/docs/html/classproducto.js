var classproducto =
[
    [ "producto", "classproducto.html#ade4a4686641f868ec6a18a26de552498", null ],
    [ "getNombres", "classproducto.html#adfbcadf358ae307b02edf95d8bb0cebd", null ],
    [ "getPrecios", "classproducto.html#aad29719885bb2e71f88de4b445af6a97", null ],
    [ "mostrar", "classproducto.html#a51833a2b7a2e9bdb8ce7a9c2d0828b06", null ],
    [ "cantidad", "classproducto.html#af0c04f0b3f346742e9bf338669ffa97f", null ],
    [ "nombres", "classproducto.html#a9ccee66445b10e1df9d47b81f14ca63c", null ],
    [ "precios", "classproducto.html#a0c95bb4246dbf7a465c251db89f4da30", null ]
];